import os, shutil,h5py
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from keras.preprocessing.image import load_img
import cv2

final_w,final_h=  32,32
zoom_interpol_method = cv2.INTER_LANCZOS4


def write_rtdc(fname,images,pos_x,pos_y):
    """
    fname - path+filename of file to be created
    images - numpy array
    pos_x - numpy array
    pos_y - numpy array
    """
    #Check if a file with name fname already exists:
    if os.path.isfile(fname):
        os.remove(fname) #delete it
        print("overwrite existing file")

    index_new = np.array(range(1,images.shape[0])) #New index. Will replace the existing index in order to support viewing imges in shapeout   

    #copy the empty Empty.rtdc
    shutil.copy("Empty.rtdc",fname)
    
    maxshape = (None, images.shape[1], images.shape[2])
    #Create rtdc_dataset
    hdf = h5py.File(fname,'a')
    hdf.create_dataset("events/image", data=images, dtype=np.uint8,maxshape=maxshape,fletcher32=True,chunks=True)
    hdf.create_dataset("events/pos_x", data=pos_x, dtype=np.int32)
    hdf.create_dataset("events/pos_y", data=pos_y, dtype=np.int32)
    hdf.create_dataset("events/index", data=index_new, dtype=np.int32)
    
    #Adjust metadata:
    #"experiment:event count" = Nr. of images
    hdf.attrs["experiment:event count"]=images.shape[0]
    hdf.attrs["experiment:sample"]=fname
    hdf.attrs["imaging:pixel size"]=1.00
    hdf.close()
    return





for smiley_type in ["happy_10","sunglasses_10","blink_10"]:
#for smiley_type in ["happy_train","sunglasses_train","blink_train","happy_valid","sunglasses_valid","blink_valid"]:
    path_images = os.listdir(smiley_type)
    smile = []
    for i in range(len(path_images)):
        img = load_img(os.path.join(smiley_type,path_images[i]))
        img = np.array(img) #convert to numpy array
        img = (0.21 * img[:,:,:1]) + (0.72 * img[:,:,1:2]) + (0.07 * img[:,:,-1:])
        img = img[:,:,0] 
        img = img.astype(np.uint8)           

        #images.append(img)
        #resize image to 32x32 pixels
        img_32 = cv2.resize(img, dsize=(final_w,final_h), interpolation=zoom_interpol_method)
        smile.append(img_32)
        
        
    #Create an image with noise only 
    h,w = 60,100
    images = np.random.randint(low=0,high=255,size=(len(smile),h,w)).astype(np.uint8)
    #arbitrary x position
    pos_x = np.random.randint(low=16,high=w-16,size=images.shape[0])
    #arbitrary height
    pos_y = np.random.randint(low=16,high=h-16,size=images.shape[0])
    #put smileys on images
    for i in range(len(images)):
        images[i][pos_y[i]-16:pos_y[i]+16,pos_x[i]-16:pos_x[i]+16] = smile[i]
    
    write_rtdc(smiley_type+"_gray.rtdc",images,pos_x,pos_y)
#np.save(smiley_type+"_32pix"+os.sep+smiley_type+"_"+str(i),img_32)

