#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "89a5f6e9c9"     # abbreviated commit hash
commit = "89a5f6e9c91b9d4b586b66889be2c5aeda8442dc"  # commit hash
date = "2020-03-01 19:18:21 +0100"   # commit date
author = "pyup-bot <github-bot@pyup.io>"
ref_names = "refs/pull/4716/head, pyup/scheduled-update-2020-03-01"  # incl. current branch
commit_message = """Update pyqtwebengine from 5.12.1 to 5.14.0"""
